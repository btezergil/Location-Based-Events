This package provides a simple implementation of a kd-tree in Python.
https://en.wikipedia.org/wiki/K-d_tree

