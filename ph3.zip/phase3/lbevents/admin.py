from django.contrib import admin

from .models import EventMap, Event

# Register your models here.

admin.site.register(EventMap)
admin.site.register(Event)
