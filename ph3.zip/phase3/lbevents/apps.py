from django.apps import AppConfig


class LbeventsConfig(AppConfig):
    name = 'lbevents'
